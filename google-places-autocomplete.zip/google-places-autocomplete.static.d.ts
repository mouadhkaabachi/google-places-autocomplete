declare const PLACES_API_URL = "https://maps.googleapis.com/maps/api/place/autocomplete/json";
declare const PLACES_DETAILS_API_URL_places = "https://maps.googleapis.com/maps/api/place/details/json";
export { PLACES_API_URL, PLACES_DETAILS_API_URL_places };
