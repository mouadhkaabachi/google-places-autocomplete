import { Common } from './google-places-autocomplete.common';
export declare class GooglePlacesAutocomplete extends Common {
}
