"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var PLACES_API_URL = 'https://maps.googleapis.com/maps/api/place/autocomplete/json';
exports.PLACES_API_URL = PLACES_API_URL;
var PLACES_DETAILS_API_URL_places = 'https://maps.googleapis.com/maps/api/place/details/json';
exports.PLACES_DETAILS_API_URL_places = PLACES_DETAILS_API_URL_places;
//# sourceMappingURL=google-places-autocomplete.static.js.map