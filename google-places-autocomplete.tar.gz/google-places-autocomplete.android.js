"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var google_places_autocomplete_common_1 = require("./google-places-autocomplete.common");
var GooglePlacesAutocomplete = (function (_super) {
    __extends(GooglePlacesAutocomplete, _super);
    function GooglePlacesAutocomplete() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    return GooglePlacesAutocomplete;
}(google_places_autocomplete_common_1.Common));
exports.GooglePlacesAutocomplete = GooglePlacesAutocomplete;
//# sourceMappingURL=google-places-autocomplete.android.js.map