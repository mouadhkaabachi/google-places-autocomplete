import { Common } from './google-places-autocomplete.common';
export declare class GooglePlacesAutocomplete extends Common {
  // define your typings manually
  // or..
  // take the ios or android .d.ts files and copy/paste them here
}
