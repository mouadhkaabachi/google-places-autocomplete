import { Common } from './google-places-autocomplete.common';
export class GooglePlacesAutocomplete extends Common {
}
//# sourceMappingURL=google-places-autocomplete.android.js.map